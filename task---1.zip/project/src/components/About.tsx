import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { Code, Palette, Zap } from 'lucide-react';

const About: React.FC = () => {
  const aboutRef = useRef<HTMLSectionElement>(null);

  useEffect(() => {
    gsap.fromTo('.about-card',
      {
        y: 50,
        opacity: 0,
        scale: 0.9
      },
      {
        y: 0,
        opacity: 1,
        scale: 1,
        duration: 0.6,
        stagger: 0.2,
        ease: "power2.out",
        scrollTrigger: {
          trigger: aboutRef.current,
          start: "top 70%",
          toggleActions: "play none none reverse"
        }
      }
    );
  }, []);

  const features = [
    {
      icon: <Code className="w-8 h-8" />,
      title: "Clean Code",
      description: "Writing maintainable, scalable, and efficient code that follows best practices."
    },
    {
      icon: <Palette className="w-8 h-8" />,
      title: "Creative Design",
      description: "Crafting visually appealing interfaces with attention to detail and user experience."
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Performance",
      description: "Optimizing applications for speed, accessibility, and seamless user interactions."
    }
  ];

  return (
    <section id="about" ref={aboutRef} className="section py-20 bg-slate-800/50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">
            About Me
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            I'm a passionate full-stack developer with over 5 years of experience creating 
            digital solutions that make a difference. I love turning complex problems into 
            simple, beautiful, and intuitive designs.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-2xl font-bold mb-6 text-white">My Journey</h3>
            <p className="text-slate-300 mb-4 leading-relaxed">
              My journey into web development started with curiosity and evolved into a passion for creating 
              meaningful digital experiences. I specialize in modern JavaScript frameworks, particularly React 
              and Node.js, with a strong focus on performance and user experience.
            </p>
            <p className="text-slate-300 leading-relaxed">
              When I'm not coding, you'll find me exploring new technologies, contributing to open-source 
              projects, or sharing knowledge with the developer community through writing and mentoring.
            </p>
          </div>
          
          <div className="relative">
            <div className="w-80 h-80 mx-auto bg-gradient-to-br from-purple-500/20 to-cyan-500/20 rounded-2xl flex items-center justify-center">
              <div className="text-6xl">👨‍💻</div>
            </div>
            <div className="absolute -top-4 -left-4 w-20 h-20 bg-purple-500/30 rounded-full blur-xl"></div>
            <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-cyan-500/20 rounded-full blur-xl"></div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="about-card bg-slate-800/80 p-8 rounded-2xl border border-slate-700 hover:border-slate-600 transition-all duration-300 hover:transform hover:scale-105"
            >
              <div className="text-purple-400 mb-4">
                {feature.icon}
              </div>
              <h4 className="text-xl font-bold mb-3 text-white">{feature.title}</h4>
              <p className="text-slate-300">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;