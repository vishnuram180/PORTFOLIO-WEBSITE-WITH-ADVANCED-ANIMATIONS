import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ArrowDown, Github, Linkedin, Mail } from 'lucide-react';

const Hero: React.FC = () => {
  const heroRef = useRef<HTMLSectionElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const socialRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline({ delay: 1 });
    
    tl.fromTo(titleRef.current,
      { y: 100, opacity: 0 },
      { y: 0, opacity: 1, duration: 1, ease: "power2.out" }
    )
    .fromTo(subtitleRef.current,
      { y: 50, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, ease: "power2.out" },
      "-=0.5"
    )
    .fromTo(ctaRef.current,
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.6, ease: "power2.out" },
      "-=0.3"
    )
    .fromTo(socialRef.current,
      { y: 20, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.5, ease: "power2.out" },
      "-=0.2"
    );

    // Floating animation for arrow
    gsap.to('.scroll-arrow', {
      y: 10,
      duration: 1.5,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut"
    });
  }, []);

  const scrollToNext = () => {
    const aboutSection = document.getElementById('about');
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      id="home"
      ref={heroRef}
      className="section min-h-screen flex items-center justify-center relative overflow-hidden"
    >
      <div className="container mx-auto px-6 text-center z-10">
        <h1 
          ref={titleRef}
          className="text-5xl md:text-7xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400"
        >
          Creative Developer
        </h1>
        
        <p 
          ref={subtitleRef}
          className="text-xl md:text-2xl text-slate-300 mb-8 max-w-3xl mx-auto leading-relaxed"
        >
          I craft beautiful, functional, and user-centered digital experiences that bring ideas to life
        </p>
        
        <div ref={ctaRef} className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <button 
            onClick={() => scrollToNext()}
            className="px-8 py-3 bg-gradient-to-r from-purple-500 to-cyan-500 text-white font-semibold rounded-full hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105"
          >
            View My Work
          </button>
          <button className="px-8 py-3 border border-slate-600 text-slate-300 font-semibold rounded-full hover:border-slate-400 hover:text-white transition-all duration-300">
            Download Resume
          </button>
        </div>

        <div ref={socialRef} className="flex justify-center space-x-6 mb-16">
          <a 
            href="#" 
            className="p-3 bg-slate-800 rounded-full hover:bg-slate-700 transition-colors duration-300 group"
          >
            <Github className="w-6 h-6 group-hover:scale-110 transition-transform duration-300" />
          </a>
          <a 
            href="#" 
            className="p-3 bg-slate-800 rounded-full hover:bg-slate-700 transition-colors duration-300 group"
          >
            <Linkedin className="w-6 h-6 group-hover:scale-110 transition-transform duration-300" />
          </a>
          <a 
            href="#" 
            className="p-3 bg-slate-800 rounded-full hover:bg-slate-700 transition-colors duration-300 group"
          >
            <Mail className="w-6 h-6 group-hover:scale-110 transition-transform duration-300" />
          </a>
        </div>

        <button 
          onClick={scrollToNext}
          className="scroll-arrow absolute bottom-8 left-1/2 transform -translate-x-1/2 text-slate-400 hover:text-white transition-colors duration-300"
        >
          <ArrowDown size={32} />
        </button>
      </div>

      {/* Gradient Orbs */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-purple-500/20 rounded-full blur-3xl parallax-slow"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/15 rounded-full blur-3xl parallax-slow"></div>
    </section>
  );
};

export default Hero;