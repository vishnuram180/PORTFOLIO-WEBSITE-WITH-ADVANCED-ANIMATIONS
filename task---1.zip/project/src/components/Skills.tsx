import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { 
  Code2, 
  Smartphone, 
  Server, 
  Database, 
  Palette, 
  Zap,
  Globe,
  GitBranch,
  Terminal,
  Layers
} from 'lucide-react';

const Skills: React.FC = () => {
  const skillsRef = useRef<HTMLSectionElement>(null);

  useEffect(() => {
    // Animate skill categories
    gsap.fromTo('.skill-category',
      {
        y: 60,
        opacity: 0
      },
      {
        y: 0,
        opacity: 1,
        duration: 0.8,
        stagger: 0.2,
        ease: "power2.out",
        scrollTrigger: {
          trigger: skillsRef.current,
          start: "top 70%",
          toggleActions: "play none none reverse"
        }
      }
    );

    // Animate individual skills
    gsap.fromTo('.skill-item',
      {
        scale: 0.8,
        opacity: 0
      },
      {
        scale: 1,
        opacity: 1,
        duration: 0.6,
        stagger: 0.05,
        ease: "back.out(1.7)",
        scrollTrigger: {
          trigger: skillsRef.current,
          start: "top 60%",
          toggleActions: "play none none reverse"
        }
      }
    );

    // Progress bar animations
    const progressBars = document.querySelectorAll('.progress-bar');
    progressBars.forEach((bar, index) => {
      const percentage = bar.getAttribute('data-percentage') || '0';
      gsap.fromTo(bar,
        { width: '0%' },
        {
          width: percentage + '%',
          duration: 1.5,
          delay: index * 0.1,
          ease: "power2.out",
          scrollTrigger: {
            trigger: skillsRef.current,
            start: "top 60%",
            toggleActions: "play none none reverse"
          }
        }
      );
    });
  }, []);

  const skillCategories = [
    {
      title: "Frontend Development",
      icon: <Code2 className="w-8 h-8" />,
      skills: [
        { name: "React/Next.js", level: 95 },
        { name: "TypeScript", level: 90 },
        { name: "Vue.js", level: 85 },
        { name: "Tailwind CSS", level: 95 },
        { name: "SASS/SCSS", level: 88 }
      ]
    },
    {
      title: "Backend Development",
      icon: <Server className="w-8 h-8" />,
      skills: [
        { name: "Node.js", level: 92 },
        { name: "Python", level: 85 },
        { name: "Express.js", level: 90 },
        { name: "GraphQL", level: 82 },
        { name: "REST APIs", level: 95 }
      ]
    },
    {
      title: "Database & Tools",
      icon: <Database className="w-8 h-8" />,
      skills: [
        { name: "MongoDB", level: 88 },
        { name: "PostgreSQL", level: 85 },
        { name: "Redis", level: 80 },
        { name: "Firebase", level: 90 },
        { name: "Docker", level: 78 }
      ]
    }
  ];

  const additionalSkills = [
    { name: "Mobile Development", icon: <Smartphone className="w-6 h-6" /> },
    { name: "UI/UX Design", icon: <Palette className="w-6 h-6" /> },
    { name: "Performance Optimization", icon: <Zap className="w-6 h-6" /> },
    { name: "Web Accessibility", icon: <Globe className="w-6 h-6" /> },
    { name: "Version Control", icon: <GitBranch className="w-6 h-6" /> },
    { name: "DevOps", icon: <Terminal className="w-6 h-6" /> },
    { name: "System Architecture", icon: <Layers className="w-6 h-6" /> }
  ];

  return (
    <section id="skills" ref={skillsRef} className="section py-20 bg-slate-800/50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">
            Skills & Expertise
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            A comprehensive overview of my technical skills and the tools I use to bring ideas to life.
            Constantly learning and evolving with the latest technologies.
          </p>
        </div>

        {/* Main Skill Categories */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {skillCategories.map((category, index) => (
            <div 
              key={index}
              className="skill-category bg-slate-800/80 p-8 rounded-2xl border border-slate-700 hover:border-slate-600 transition-all duration-300"
            >
              <div className="flex items-center mb-6">
                <div className="text-purple-400 mr-4">
                  {category.icon}
                </div>
                <h3 className="text-xl font-bold text-white">{category.title}</h3>
              </div>
              
              <div className="space-y-6">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="skill-item">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-slate-300 font-medium">{skill.name}</span>
                      <span className="text-slate-400 text-sm">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2">
                      <div 
                        className="progress-bar bg-gradient-to-r from-purple-500 to-cyan-500 h-2 rounded-full"
                        data-percentage={skill.level}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Additional Skills */}
        <div className="skill-category">
          <h3 className="text-2xl font-bold mb-8 text-center text-white">Additional Expertise</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-6">
            {additionalSkills.map((skill, index) => (
              <div 
                key={index}
                className="skill-item flex flex-col items-center p-6 bg-slate-800/60 rounded-xl border border-slate-700 hover:border-slate-600 hover:bg-slate-800/80 transition-all duration-300 group cursor-pointer"
              >
                <div className="text-purple-400 mb-3 group-hover:scale-110 transition-transform duration-300">
                  {skill.icon}
                </div>
                <span className="text-slate-300 text-sm text-center font-medium group-hover:text-white transition-colors duration-300">
                  {skill.name}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Certifications */}
        <div className="skill-category mt-16 text-center">
          <h3 className="text-2xl font-bold mb-8 text-white">Certifications & Achievements</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="skill-item bg-slate-800/60 p-6 rounded-xl border border-slate-700">
              <h4 className="text-lg font-semibold text-purple-400 mb-2">AWS Certified</h4>
              <p className="text-slate-300">Cloud Solutions Architect</p>
            </div>
            <div className="skill-item bg-slate-800/60 p-6 rounded-xl border border-slate-700">
              <h4 className="text-lg font-semibold text-cyan-400 mb-2">Google Cloud</h4>
              <p className="text-slate-300">Professional Developer</p>
            </div>
            <div className="skill-item bg-slate-800/60 p-6 rounded-xl border border-slate-700">
              <h4 className="text-lg font-semibold text-pink-400 mb-2">React Advanced</h4>
              <p className="text-slate-300">Meta Certification</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;