import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { Mail, Phone, MapPin, Send, Github, Linkedin, Twitter } from 'lucide-react';

const Contact: React.FC = () => {
  const contactRef = useRef<HTMLSectionElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    // Animate contact section
    gsap.fromTo('.contact-content',
      {
        y: 80,
        opacity: 0
      },
      {
        y: 0,
        opacity: 1,
        duration: 1,
        stagger: 0.2,
        ease: "power2.out",
        scrollTrigger: {
          trigger: contactRef.current,
          start: "top 70%",
          toggleActions: "play none none reverse"
        }
      }
    );

    // Form field animations
    const formFields = document.querySelectorAll('.form-field');
    formFields.forEach((field, index) => {
      const input = field.querySelector('input, textarea');
      const label = field.querySelector('label');

      if (input && label) {
        input.addEventListener('focus', () => {
          gsap.to(label, {
            y: -25,
            scale: 0.85,
            color: '#a855f7',
            duration: 0.3,
            ease: "power2.out"
          });
        });

        input.addEventListener('blur', (e: any) => {
          if (!e.target.value) {
            gsap.to(label, {
              y: 0,
              scale: 1,
              color: '#94a3b8',
              duration: 0.3,
              ease: "power2.out"
            });
          }
        });
      }
    });
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Reset form
    setFormData({ name: '', email: '', subject: '', message: '' });
    setIsSubmitting(false);

    // Show success animation
    gsap.fromTo('.success-message',
      { opacity: 0, scale: 0.8 },
      { opacity: 1, scale: 1, duration: 0.5, ease: "back.out(1.7)" }
    );

    setTimeout(() => {
      gsap.to('.success-message', {
        opacity: 0,
        duration: 0.3
      });
    }, 3000);
  };

  const contactInfo = [
    {
      icon: <Mail className="w-6 h-6" />,
      title: "Email",
      content: "hello@yourname.com",
      link: "mailto:hello@yourname.com"
    },
    {
      icon: <Phone className="w-6 h-6" />,
      title: "Phone",
      content: "+1 (555) 123-4567",
      link: "tel:+15551234567"
    },
    {
      icon: <MapPin className="w-6 h-6" />,
      title: "Location",
      content: "San Francisco, CA",
      link: "#"
    }
  ];

  const socialLinks = [
    { icon: <Github className="w-5 h-5" />, link: "#", label: "GitHub" },
    { icon: <Linkedin className="w-5 h-5" />, link: "#", label: "LinkedIn" },
    { icon: <Twitter className="w-5 h-5" />, link: "#", label: "Twitter" }
  ];

  return (
    <section id="contact" ref={contactRef} className="section py-20 bg-slate-900 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 contact-content">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">
            Let's Work Together
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Have a project in mind? I'd love to hear about it. Let's discuss how we can bring your ideas to life.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Contact Information */}
          <div className="contact-content">
            <h3 className="text-2xl font-bold mb-8 text-white">Get In Touch</h3>
            
            <div className="space-y-6 mb-8">
              {contactInfo.map((info, index) => (
                <a 
                  key={index}
                  href={info.link}
                  className="flex items-center p-4 bg-slate-800/60 rounded-xl border border-slate-700 hover:border-slate-600 transition-all duration-300 group"
                >
                  <div className="text-purple-400 mr-4 group-hover:scale-110 transition-transform duration-300">
                    {info.icon}
                  </div>
                  <div>
                    <h4 className="text-slate-300 font-medium">{info.title}</h4>
                    <p className="text-white font-semibold">{info.content}</p>
                  </div>
                </a>
              ))}
            </div>

            <div className="mb-8">
              <h4 className="text-lg font-semibold mb-4 text-white">Follow Me</h4>
              <div className="flex space-x-4">
                {socialLinks.map((social, index) => (
                  <a 
                    key={index}
                    href={social.link}
                    className="p-3 bg-slate-800 rounded-full hover:bg-gradient-to-r hover:from-purple-500 hover:to-cyan-500 transition-all duration-300 group"
                    aria-label={social.label}
                  >
                    <div className="group-hover:scale-110 transition-transform duration-300">
                      {social.icon}
                    </div>
                  </a>
                ))}
              </div>
            </div>

            <div className="p-6 bg-gradient-to-br from-purple-500/10 to-cyan-500/10 rounded-2xl border border-purple-500/20">
              <h4 className="text-lg font-semibold mb-2 text-white">Quick Response</h4>
              <p className="text-slate-300">
                I typically respond to messages within 24 hours. Looking forward to hearing from you!
              </p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="contact-content">
            <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="form-field relative">
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full p-4 bg-slate-800/60 border border-slate-700 rounded-xl text-white placeholder-transparent focus:border-purple-500 focus:outline-none transition-colors duration-300"
                    placeholder="Your Name"
                    required
                  />
                  <label className="absolute left-4 top-4 text-slate-400 pointer-events-none">
                    Your Name
                  </label>
                </div>

                <div className="form-field relative">
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full p-4 bg-slate-800/60 border border-slate-700 rounded-xl text-white placeholder-transparent focus:border-purple-500 focus:outline-none transition-colors duration-300"
                    placeholder="Your Email"
                    required
                  />
                  <label className="absolute left-4 top-4 text-slate-400 pointer-events-none">
                    Your Email
                  </label>
                </div>
              </div>

              <div className="form-field relative">
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  className="w-full p-4 bg-slate-800/60 border border-slate-700 rounded-xl text-white placeholder-transparent focus:border-purple-500 focus:outline-none transition-colors duration-300"
                  placeholder="Subject"
                  required
                />
                <label className="absolute left-4 top-4 text-slate-400 pointer-events-none">
                  Subject
                </label>
              </div>

              <div className="form-field relative">
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  rows={6}
                  className="w-full p-4 bg-slate-800/60 border border-slate-700 rounded-xl text-white placeholder-transparent focus:border-purple-500 focus:outline-none transition-colors duration-300 resize-none"
                  placeholder="Your Message"
                  required
                />
                <label className="absolute left-4 top-4 text-slate-400 pointer-events-none">
                  Your Message
                </label>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full p-4 bg-gradient-to-r from-purple-500 to-cyan-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105 disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Sending...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    <span>Send Message</span>
                  </>
                )}
              </button>
            </form>

            {/* Success Message */}
            <div className="success-message fixed top-8 right-8 bg-green-500 text-white p-4 rounded-lg shadow-lg opacity-0 z-50">
              Message sent successfully! 🎉
            </div>
          </div>
        </div>
      </div>

      {/* Background Effects */}
      <div className="absolute top-1/4 left-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl"></div>
    </section>
  );
};

export default Contact;